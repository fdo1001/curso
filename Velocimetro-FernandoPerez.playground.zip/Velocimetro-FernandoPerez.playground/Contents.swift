

enum Velocidades : Int{
    
    case Apagado=0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init ( velocidadInicial : Velocidades){
        
        self = velocidadInicial
    }
    
}


class Auto{
    
    var velocidad : Velocidades
    
    init(){
        
        self.velocidad = .Apagado
    }
    
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String) {
        
        var velocidadEnCadena = ""
        var actual = 0
        
        switch self.velocidad {
        case .Apagado:
            velocidadEnCadena = "Apagado"
            actual = self.velocidad.rawValue
            self.velocidad = .VelocidadBaja
            
        case .VelocidadBaja:
             velocidadEnCadena = "Velocidad baja"
             actual = self.velocidad.rawValue
            self.velocidad = .VelocidadMedia
           
        case .VelocidadMedia:
             velocidadEnCadena = "Velocidad media"
             actual = self.velocidad.rawValue
            self.velocidad = .VelocidadAlta
           
        case .VelocidadAlta:
             velocidadEnCadena = "Velocidad alta"
             actual = self.velocidad.rawValue
            self.velocidad = .VelocidadMedia
        }
        
        
        return (actual, velocidadEnCadena)
    }
}

var auto = Auto()

for i in 1...20{
    
    print (auto.cambioDeVelocidad())
    
}